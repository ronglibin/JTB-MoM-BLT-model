function y=SImodel(t,par1)
miuT=par1(1); P=par1(2);   %P=NT*KT*T0
y=1.38*10^6*(P/(23-miuT)*exp(-miuT*t)+(23-P)/22.42*exp(-0.58*t)+(1-P/(23-miuT)-(23-P)/22.42)*exp(-23*t));
end 


