clear all
clc
ID=[1.38*10^6 8.62*10^4 4.48*10^4 4020 1771 2658 840.3 935.9 334 334 334];
ID1=[1.38*10^6 8.62*10^4 4.48*10^4 4020 1771 2658 840.3 935.9 334];  %ȥ����������
lb=[0.58 1];
ub=[1.2 10];
par1guess=[0.8 9.9];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID1)
t=0:0.1:56;
for i=1:length(t)
    X1(i)=SImodel(t(i),par1);
end
figure(1)
plot(t,log10(X1(:)),'k-',0:7:70,log10(ID),'bo');   %ֻ�����ͼ�����õ����������ݵ�
title('(b)')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

hold on
plot([0 70],[1,1]*log10(668),'r--')


%  miuT=0.66; P=2.4715

