function d=LSmin(par1,ID1)
t=0:0.1:56;
for i=1:length(t)
    y(i)=SImodel(t(i),par1);
end
for j=1:1:9
ysimulation(j)=y(1+70*(j-1));
end
d=norm(log10(ysimulation)-log10(ID1))^2;
end
