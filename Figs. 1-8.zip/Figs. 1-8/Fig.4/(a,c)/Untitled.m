clear all
clc
ID=[1.38*10^6 8.62*10^4 4.48*10^4 4020 1771 2658 840.3 935.9 334 334 334];
ID1=[1.38*10^6 8.62*10^4 4.48*10^4 4020 1771 2658 840.3 935.9 334];  %ȥ����������
lb=[0.58 0.01 1 0 0];
ub=[1.2 0.1 14 0.09 0.001];
par1guess=[0.6 0.0368 11 0.02 0.0001];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID1)
t=0:0.1:56;
for i=1:length(t)
    X1(i)=SImodel(t(i),par1);
end
figure(1)
plot(t,log10(X1(:)),'k-',0:7:70,log10(ID),'bo'); 
title('(a)')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

% miuT=0.58; delta=0.0602;  P=14;  f=0.0461;  q=0.001  %���Ų���ֵ
%miuT=par1(1); delta=par1(2);  P=par1(3);  f=par1(4);  q=par1(5); %P=NT*KT*T0   q=a*f

% 
% K=10.9884/(23-0.2548)*((1-0.0495)+0.0006/0.0548-0.0006*0.2548/(0.0548*(0.2548-0.0548)))
% L=(0.0006*0.2548*10.9884)/(0.0548*(23-0.0548)*(0.2548-0.0548))
% P=1/(23-0.58)*(23-(1-0.0495)*10.9884-0.0006*10.9884/0.0548)
% D1=(log(P/K))/(0.58-0.2548)
% D2=(log(K/L))/(0.2548-0.0548)

K=par1(3)/(23-par1(1))*((1-par1(4))+par1(5)/par1(2)-par1(5)*par1(1)/(par1(2)*(par1(1)-par1(2))))
L=(par1(5)*par1(1)*par1(3))/(par1(2)*(23-par1(2))*(par1(1)-par1(2)))
P=1/(23-0.58)*(23-(1-par1(4))*par1(3)-par1(5)*par1(3)/par1(2))
D1=(log((K+P)/L))/(0.58-par1(2))

 
 hold on
 tf=0:0.01:D1;
 plot(tf,log10(1.38*10^6*(K+P)*exp(-0.58*tf)),'b-'); 

 hold on
 tx=D1:0.01:56;
 plot(tx,log10(1.38*10^6*L*exp(-par1(2)*tx)),'g--');
 
 hold on
 plot([0 70],[1,1]*log10(668),'k--')
      
  legend('Fitting curve','Data','$log_{10}(\bar{V}(K+P)e^{-\mu_{T}t_{1}})$','$log_{10}(\bar{V}Le^{-\delta t_{3}})$','detection limit')
   set(legend,'interpreter','latex'); 
 
  text(D1,2.3,'D_{1}') 
                          