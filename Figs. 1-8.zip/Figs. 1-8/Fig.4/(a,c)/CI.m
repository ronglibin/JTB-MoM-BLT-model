clear all
clc

% load data
%----------------------数据-------------%
[Data] = [1.38*10^6 8.62*10^4 4.48*10^4 4020 1771 2658 840.3 935.9 334];

Mat1_par_after_allp=[0.58 0.0602 14 0.0461 0.001];     %最拟合的5个参数值 
par = Mat1_par_after_allp;  %miuT=par1(1); delta=par1(2);  P=par1(3);  f=par1(4);  q=par1(5); %P=NT*KT*T0   q=a*f

%%
%global N_0 mu Lambda t_end New_Cases_After_Omicron Proportions_After_Omicron Time_Proportion t_end2

Time_After =0:7:56;
t_end = length(Time_After);
%----------------------数据-------------%


%----------------------初值-------------%
% N_0 = 332398949;
% mu = 1/(79*365);
% Lambda = N_0*mu;
%----------------------初值-------------%
%%
% scale_variation_rep=rand(200,1)*0.09+0.01;
scale_variation_rep=0.2;   %扰动值
loop=100;  %循环数
rep=length(scale_variation_rep); %重复值函数
matrix_3D=zeros(loop,t_end+length(par),rep);%100*14*1
for i=1:rep
    scale_variation=scale_variation_rep(i);
    lb=par*(1-scale_variation);   %扰动区间下限
    ub=par*(1+scale_variation);   %扰动区间上限
    new_cases_matrix = zeros(loop,t_end);    %100*9
    MCMC_Par=zeros(loop,length(par));   %100*5
for j=1:loop
    Npar=lb+2*scale_variation*par.*lhsdesign(1,length(par));  %扰动后的参数值   1*5   每次都不一样，拉丁超立方抽样随意去取  
    %这样写是为了保证参数的上限是ub
   
    
    
    t=0:0.1:56;
for ll=1:length(t)
    X(ll)=SImodel(t(ll),Npar);
end
    V(1)=X(1);
    V(2)=X(71);
    V(3)=X(141);
    V(4)=X(211);
    V(5)=X(281);
    V(6)=X(351);
    V(7)=X(421);
    V(8)=X(497);
     V(9)=X(561);
        
    new_cases_ci = [log10(V(1)) log10(V(2)) log10(V(3)) log10(V(4)) log10(V(5)) log10(V(6)) log10(V(7)) log10(V(8)) log10(V(9))];

    new_cases_matrix(j,:)= new_cases_ci;   %扰动后的病例数
    MCMC_Par(j,:)=Npar;  %扰动后的参数
end
matrix=[new_cases_matrix MCMC_Par];  %100*9，100*5
matrix_3D(:,:,i)=matrix;
end
Mat3_matrix_3D=matrix_3D;   %100*14
% save Mat3_matrix_3D Mat3_matrix_3D

sz=size(Mat3_matrix_3D);   %100*14    矩阵的大小
matrix_ci_2D=zeros(rep,sz(2)*3);  %1*42
Ncover=zeros(rep,1);
SSEcover=zeros(rep,1);
for a=1:rep
    matrix=Mat3_matrix_3D(:,:,a);
    matrix_mean=zeros(1,sz(2));  %1*14
    matrix_ci_l=zeros(1,sz(2));   %1*14
    matrix_ci_h=zeros(1,sz(2));   %1*14
    for b=1:sz(2)
        matrix_mean(b)=mean(matrix(1:100,b));
        matrix_ci_l(b)=mean(matrix(1:100,b))-1.96*std(matrix(1:100,b));  %根据95%的置信区间得到的1.96    1*14
        matrix_ci_h(b)=mean(matrix(1:100,b))+1.96*std(matrix(1:100,b));   % 1*14
    end 
    matrix_ci=[matrix_mean matrix_ci_l matrix_ci_h];   %1*42
    matrix_ci_2D(a,:)=matrix_ci;
    
    %max1=max(log10(Data));   %新感染数据的最大值
    
    range1=1:t_end;     %1~9

    
    data4=log10(Data)';    %1*9
    l=matrix_ci_l(range1);  %置信区间对应的数值下限
    h=matrix_ci_h(range1);   %置信区间对应的数值上限
    
      
      
    Nc=0;
    SSE=0;
    %----------------------在1~50，数值在上下限内-------------%
    for c=range1
        if data4(c)>l(c) & data4(c)<h(c)
           Nc=Nc+1;
           SSE=SSE+norm(matrix(:,c)-data4(c))^2;  
        end   
    end
  %----------------------在1~50，数值在上下限内-------------%
  
  
%     for c=t_end+1:t_end+t_end2
%         if data4(c)>l(c) & data4(c)<h(c)
%            Nc=Nc+1;
%            SSE=SSE+norm(matrix(:,c)/max2-data4(c)/max2)^2;   %扰动之后的SSE
%         end   
%     end
   
    Ncover(a)=Nc;
    SSEcover(a)=SSE;   
end
Mat4_Matrix_CI=[matrix_ci_2D scale_variation_rep SSEcover Ncover SSEcover./Ncover];   %1*46
save Mat4_Matrix_CI Mat4_Matrix_CI
[value,min_hang]=min(Mat4_Matrix_CI(:,end));
Mat3_Matrix_3D=Mat3_matrix_3D(:,:,min_hang);
save Mat3_Matrix_3D Mat3_Matrix_3D


%%
% function dy = US_ODE(~, y, beta_A1, beta_I1, alpha_1, omega_1, gamma_A1, gamma_I1, beta_A2, beta_I2, alpha_2, omega_2, gamma_A2, gamma_I2)
% 
% global mu Lambda 
% % define variables
% 
%     S = y(1);
%     A_1 = y(2);
%     I_1 = y(3);
%     A_2 = y(4);
%     I_2 = y(5);
%     R = y(6);
% 
%  lambda_1= beta_A1*A_1 + beta_I1*I_1;
%  lambda_2= beta_A2*A_2 + beta_I2*I_2;
%  
%  dy=zeros(6,1);   
%  dy(1) = Lambda - (lambda_1+lambda_2)*S-mu*S;
%  dy(2) = lambda_1*S - (alpha_1+gamma_A1+mu)*A_1;
% %  dy(2) = lambda_1*(S+(1-tau)*R) - (alpha_1+gamma_A1+mu)*A_1;
%  dy(3) = alpha_1*A_1 - (omega_1+gamma_I1+mu)*I_1;
%  dy(4) = lambda_2*S - (alpha_2+gamma_A2+mu)*A_2;
%  dy(5) = alpha_2*A_2 - (omega_2+gamma_I2+mu)*I_2;
%  dy(6) = gamma_A1*A_1 + gamma_I1*I_1 + gamma_A2*A_2 + gamma_I2*I_2-mu*R;
% end