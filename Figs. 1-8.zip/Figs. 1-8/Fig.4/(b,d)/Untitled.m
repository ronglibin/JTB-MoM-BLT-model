clear all
clc
ID=[2.34*10^5 1.38*10^6 1.69*10^6 1.35*10^6 2.34*10^6 9.61*10^5 3.64*10^5 3.06*10^5 9.65*10^5 5.82*10^5 4.88*10^5 4.68*10^5 8.41*10^5 1.56*10^6];
%ID=[2.34*10^5 1.38*10^6 1.69*10^6 1.35*10^6 2.34*10^6 9.61*10^5 3.64*10^5 3.06*10^5 9.65*10^5 5.82*10^5];
X0=[2.4*10^5 1 30 1.89*10^4 10 334];
lb=[10^2 0.01 10^(-8)];
ub=[10^4 0.3 10^(-6)];
par1guess=[3.22*10^3 0.015 6.254*10^(-8)];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0:0.01:100],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,6)),'k-',7:7:100,log10(ID),'bo'); 
title('(b)')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

%  sT=3220; dT=0.016; kT=8.051*10^(-8)

