clear all
clc

% load data
%----------------------数据-------------%
[Data] = [2.34*10^5 1.38*10^6 1.69*10^6 1.35*10^6 2.34*10^6 9.61*10^5 3.64*10^5 3.06*10^5 9.65*10^5 5.82*10^5 4.88*10^5 4.68*10^5 8.41*10^5 1.56*10^6];

Mat1_par_after_allp=[3220 0.016 8.051*10^(-8)];     %最拟合的3个参数值
par = Mat1_par_after_allp;  %sT=par1(1); dT=par1(2); kT=par1(3);

%%
%global N_0 mu Lambda t_end New_Cases_After_Omicron Proportions_After_Omicron Time_Proportion t_end2

Time_After =7:7:98;
t_end = length(Time_After);
%----------------------数据-------------%

%load Mat1_par_after_omicron_allp
par1=Mat1_par_after_allp;
load Mat4_Matrix_CI 
T=1:t_end;

[value,min_hang]=min(Mat4_Matrix_CI(:,end));

ci_num=t_end+length(par1);   %17
matrix_ci=[Mat4_Matrix_CI(min_hang,1:ci_num)
    Mat4_Matrix_CI(min_hang,1+ci_num:ci_num*2)
    Mat4_Matrix_CI(min_hang,1+ci_num*2:ci_num*3)];   %3*17   最终参数的取值范围就看这个矩阵的后三列，其中第2和3行为最小值和最大值
range_c=1:t_end;

cases_ci = matrix_ci(:,range_c);
% proportions_ci = matrix_ci(:,t_end+1:t_end*2);
% par_ci = matrix_ci(:,1+t_end*2:length(par1)+t_end*2);


%%
figure
hold on
plot(T,cases_ci(1,:),'k-','LineWidth',2)
plot(1:t_end,log10(Data),'bo','MarkerSize',8)
h=fill([T,fliplr(T)],[cases_ci(2,:),fliplr(cases_ci(3,:))],'r');
set(h,'edgealpha',0,'facealpha',0.4)
hold off
xlim([1 t_end])
xticks([1   4    7  10  14])
xticklabels({'7'  '28'  '49'  '70' '98' })
xtickangle(30)
ylim([2 7])
yticks([2   3    4  5  6 7])
yticklabels({'2'  '3'  '4'  '5' '6' '7'})
set(gca,'box','on','linewidth',1.5,'fontsize',15,'fontname','Times');
title('(d)')
xlabel('t(day)')
ylabel('log_{10} RNA copies/ml')
legend({'Fitting curve','Data'})
%%