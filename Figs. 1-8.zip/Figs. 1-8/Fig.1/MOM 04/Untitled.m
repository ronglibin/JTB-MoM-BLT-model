clear all
clc
ID=[5670 4701 1287 5100 2.54*10^4 8730 1246 1.36*10^4 2.46*10^4 7418];
X0=[1.96*10^5 20 334];
lb=[0.1 10^(-7) 100];
ub=[0.7 10^(-5) 1000];
par1guess=[0.62 5.38*10^(-7) 601];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0 70],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,3)),'k-',7:7:70,log10(ID),'bo'); 
title('MoM 04')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

%  dM=0.3495; kM=5.095*10^(-7);  NM=601

