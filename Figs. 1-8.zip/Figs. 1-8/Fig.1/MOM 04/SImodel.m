function dy=SImodel(t,y,par1)
dy=zeros(3,1);
dM=par1(1); kM=par1(2); NM=par1(3);
dy=[77100*dM-dM*y(1)-kM*y(1)*y(3); kM*y(1)*y(3)-0.58*y(2); 0.58*NM*y(2)-23*y(3)];
end 
