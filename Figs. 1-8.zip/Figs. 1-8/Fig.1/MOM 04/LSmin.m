function d=LSmin(par1,ID,X0)
[T,x]=ode45(@SImodel,[0:0.1:70],X0,[],par1);
for j=1:1:10
xsimulation(j)=x(1+70*j,3);
end
d=norm(log10(xsimulation)-log10(ID))^2;
end

