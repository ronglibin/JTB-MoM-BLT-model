clear all
clc
ID=[3.17*10^5 7.58*10^4 1.54*10^5 2.83*10^5 2.79*10^5 1.91*10^5 1.95*10^5 2.12*10^5 3.3*10^5];
X0=[2.6562*10^5 13 334];
lb=[0.1 10^(-7) 500];
ub=[0.6 10^(-6) 1000];
par1guess=[0.23 6.0*10^(-7) 837];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0 70],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,3)),'k-',14:7:70,log10(ID),'bo'); 
title('MoM 02')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')


%dM=0.22    kM=5.336*10^(-7)       NM=837


