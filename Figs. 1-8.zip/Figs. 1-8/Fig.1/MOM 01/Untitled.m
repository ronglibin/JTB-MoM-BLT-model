clear all
clc
ID=[9977 2.8*10^4 7.32*10^4 1.24*10^5 1.05*10^5 1.61*10^5 1.23*10^6 1.22*10^6];
X0=[2.18*10^5 11 334];
lb=[0.1 10^(-8) 100];
ub=[0.65 10^(-5) 1800];
par1guess=[0.3 3.584*10^(-7) 1019];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0 63],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,3)),'k-',14:7:63,log10(ID),'bo'); 
title('MoM 01')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')


%  dM=0.649; kM=3.604*10^(-7);  NM=1019

