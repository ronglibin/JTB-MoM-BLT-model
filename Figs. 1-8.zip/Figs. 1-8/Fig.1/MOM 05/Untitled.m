clear all
clc
ID=[5.48*10^4 4.04*10^4 5.93*10^4 7.15*10^4 1.01*10^5 5.05*10^4 9.62*10^4 5.83*10^4 9.43*10^4];
X0=[5.69*10^5 22 334];
lb=[0.1 10^(-8) 100];
ub=[1 10^(-5) 1200];
par1guess=[0.82 6.02*10^(-7) 537];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0 70],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,3)),'k-',14:7:70,log10(ID),'bo'); 
title('MoM 05')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

%  dM=0.749; kM=5.912*10^(-7);  NM=537

