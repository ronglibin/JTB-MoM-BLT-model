clear all
clc
ID=[6.2*10^5 6.06*10^5 5.37*10^5 6*10^5 7.71*10^5 5.29*10^5 7*10^5 6.52*10^5 7.49*10^5];
X0=[3.44*10^5 5 334];
lb=[0.1 10^(-8) 100];
ub=[0.6 10^(-5) 1800];
par1guess=[0.3 4.76*10^(-7) 1246];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0 70],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,3)),'k-',14:7:70,log10(ID),'bo'); 
title('MoM 06')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

%  dM=0.307; kM=5.107*10^(-7);  NM=1246

