clear all
clc
ID=[1864 2.01*10^4 6.45*10^4 9.43*10^4 9.29*10^4 1.4*10^5 9.56*10^5];
X0=[7.2368*10^4 10 334];
lb=[0.01 10^(-8) 400];
ub=[0.7 10^(-6) 1500];
par1guess=[0.49 3.11*10^(-7) 1328];
options=optimset('Display','final','MaxIter', 2000,'MaxFunEvals',2000);
%options=optimset('Algorithm','active-set');
[par1,fval,EXITFLAG,OUTPUT]=fmincon(@LSmin,par1guess,[],[],[],[],lb,ub,[],options,ID,X0)
[T1,X1]=ode45(@SImodel,[0 56],X0,[],par1);
figure(1)
plot(T1,log10(X1(:,3)),'k-',14:7:56,log10(ID),'bo'); 
title('MoM 03')
xlabel('t(day)'),ylabel('log_{10} RNA copies/ml')

%  d3=0.5999; k2=4.1265*10^(-7);  N2=842.3425

