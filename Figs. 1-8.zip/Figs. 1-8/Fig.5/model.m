function dy=model(t,y,sT,dT,kT,epsilong,f,a,miuT,miuL,sM,dM,g,kM,miuM,NT,NM,c)
dy=zeros(6,1);
dy(1)=sT-dT*y(1)-(1-epsilong)*kT*y(1)*y(6);
dy(2)=(1-f)*(1-epsilong)*kT*y(1)*y(6)+a*y(3)-miuT*y(2);
dy(3)=f*(1-epsilong)*kT*y(1)*y(6)-a*y(3)-miuL*y(3);
dy(4)=sM-dM*y(4)-(1-g*epsilong)*kM*y(4)*y(6);
dy(5)=(1-g*epsilong)*kM*y(4)*y(6)-miuM*y(5);
dy(6)=NT*miuT*y(2)+NM*miuM*y(5)-c*y(6);
end