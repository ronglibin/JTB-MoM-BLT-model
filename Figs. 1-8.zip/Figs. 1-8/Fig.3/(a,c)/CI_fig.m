clear all
clc

% load data
%----------------------数据-------------%
[Data] = [1.38*10^6 8.62*10^4 4.48*10^4 4020 1771 2658 840.3 935.9 334];

Mat1_par_after_allp=[0.2548 0.0548 10.9926 0.0501 0.0006];     %最拟合的5个参数值
par = Mat1_par_after_allp;  %miuT=par1(1); delta=par1(2);  P=par1(3);  f=par1(4);  q=par1(5); %P=NT*KT*T0   q=a*f

%%
%global N_0 mu Lambda t_end New_Cases_After_Omicron Proportions_After_Omicron Time_Proportion t_end2

Time_After =0:7:56;
t_end = length(Time_After);
%----------------------数据-------------%

%load Mat1_par_after_omicron_allp
par1=Mat1_par_after_allp;
load Mat4_Matrix_CI 
T=1:t_end;

[value,min_hang]=min(Mat4_Matrix_CI(:,end));

ci_num=t_end+length(par1);   %14
matrix_ci=[Mat4_Matrix_CI(min_hang,1:ci_num)
    Mat4_Matrix_CI(min_hang,1+ci_num:ci_num*2)
    Mat4_Matrix_CI(min_hang,1+ci_num*2:ci_num*3)];   %3*14
range_c=1:t_end;

cases_ci = matrix_ci(:,range_c);
% proportions_ci = matrix_ci(:,t_end+1:t_end*2);
% par_ci = matrix_ci(:,1+t_end*2:length(par1)+t_end*2);


%%
figure
hold on
plot(T,cases_ci(1,:),'k-','LineWidth',2)
plot(1:t_end,log10(Data),'bo','MarkerSize',8)
h=fill([T,fliplr(T)],[cases_ci(2,:),fliplr(cases_ci(3,:))],'r');
set(h,'edgealpha',0,'facealpha',0.4)
hold off
xlim([1 t_end])
xticks([1   4    7    9])
xticklabels({'0'  '21'  '42'  '56' })
xtickangle(30)
set(gca,'box','on','linewidth',1.5,'fontsize',15,'fontname','Times');
title('(c)')
xlabel('t(day)')
ylabel('log_{10} RNA copies/ml')
legend({'Fitting curve','Data'})
%%