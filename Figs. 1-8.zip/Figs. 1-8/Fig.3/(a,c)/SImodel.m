function y=SImodel(t,par1)
miuT=par1(1); delta=par1(2);  P=par1(3);  f=par1(4);  q=par1(5); %P=NT*KT*T0   q=a*f
y=1.38*10^6*(P/(23-miuT)*((1-f)+q/delta-q*miuT/(delta*(miuT-delta)))*exp(-miuT*t)+(q*miuT*P)/(delta*(23-delta)*(miuT-delta))*exp(-delta*t)+1/(23-0.58)*(23-(1-f)*P-q*P/delta)*exp(-0.58*t)+(1-(P/(23-miuT)*((1-f)+q/delta-q*miuT/(delta*(miuT-delta))))-(q*miuT*P)/(delta*(23-delta)*(miuT-delta))-(1/(23-0.58)*(23-(1-f)*P-q*P/delta)))*exp(-23*t));
end 

